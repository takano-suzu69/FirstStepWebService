// AWS SDK v3のインポート
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, QueryCommand, PutCommand, UpdateCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');

// DynamoDBクライアントの初期化
const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);

// CORS対応のヘッダー
const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://*.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-XSRF-TOKEN',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Credentials': 'true',
  'Content-Type': 'application/json'
};

// uuidパッケージがない場合の代替関数
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// HTML特殊文字をエスケープする関数（XSS対策）
function sanitizeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// センシティブフィールドのリスト
const sensitiveFields = [
  'password', 'token', 'accessToken', 'idToken', 'refreshToken', 
  'authorization', 'apiKey', 'secret', 'credentials', 'key',
  'sub', 'email', 'phone', 'address', 'birthdate', 'ssn'
];

// ログ出力のためのユーティリティ関数
const logger = {
  // センシティブ情報をマスクする関数
  maskSensitiveData: function(obj) {
    if (!obj) return obj;
    
    // オブジェクトをディープコピー
    const masked = JSON.parse(JSON.stringify(obj));
    
    // オブジェクトを再帰的に処理
    const maskRecursive = (obj) => {
      if (!obj || typeof obj !== 'object') return;
      
      Object.keys(obj).forEach(key => {
        // キーがセンシティブかチェック（大文字小文字を区別しない）
        const lowerKey = key.toLowerCase();
        const isSensitive = sensitiveFields.some(field => lowerKey.includes(field.toLowerCase()));
        
        if (isSensitive && typeof obj[key] === 'string') {
          // センシティブな文字列をマスク
          const value = obj[key];
          if (value.length > 6) {
            obj[key] = value.substring(0, 3) + '***' + value.substring(value.length - 3);
          } else if (value.length > 0) {
            obj[key] = '******';
          }
        } else if (obj[key] && typeof obj[key] === 'object') {
          // オブジェクトや配列を再帰的に処理
          maskRecursive(obj[key]);
        }
      });
    };
    
    maskRecursive(masked);
    return masked;
  },
  
  // 安全にログ出力する関数
  info: function(message, data) {
    if (data) {
      console.log(message, this.maskSensitiveData(data));
    } else {
      console.log(message);
    }
  },
  
  error: function(message, error, data) {
    if (error && error.stack) {
      // エラースタックからセンシティブ情報を除去
      const sanitizedStack = error.stack
        .split('\n')
        .filter(line => !sensitiveFields.some(field => line.toLowerCase().includes(field.toLowerCase())))
        .join('\n');
      
      if (data) {
        console.error(message, { ...this.maskSensitiveData(error), stack: sanitizedStack }, this.maskSensitiveData(data));
      } else {
        console.error(message, { ...this.maskSensitiveData(error), stack: sanitizedStack });
      }
    } else if (data) {
      console.error(message, this.maskSensitiveData(error), this.maskSensitiveData(data));
    } else if (error) {
      console.error(message, this.maskSensitiveData(error));
    } else {
      console.error(message);
    }
  }
};

// エラーレスポンスを生成する共通関数
function createErrorResponse(statusCode, message, error = null, headers = corsHeaders) {
  // エラーメッセージをユーザー向けに一般化
  const publicErrorMessages = {
    400: 'リクエストが不正です',
    401: '認証が必要です',
    403: 'アクセス権限がありません',
    404: 'リソースが見つかりません',
    409: 'リソースの競合が発生しました',
    500: 'サーバー内部エラーが発生しました'
  };
  
  // 詳細なエラー情報をログに記録（サーバーサイドのみ）
  if (error) {
    logger.error(`Error details for ${statusCode} response:`, error);
  }
  
  // クライアントに返すエラーレスポンス（最小限の情報のみ）
  const errorResponse = {
    statusCode: statusCode,
    headers: headers,
    body: JSON.stringify({
      status: 'error',
      code: statusCode,
      message: message || publicErrorMessages[statusCode] || 'エラーが発生しました'
    })
  };
  
  return errorResponse;
}

// GETリクエストの処理
async function handleGet(event, userId) {
  try {
    logger.info('GET request received', { path: event.path, method: event.httpMethod });
    
    // 特定のタスクを取得
    if (event.pathParameters && event.pathParameters.taskId) {
      const taskId = event.pathParameters.taskId;
      logger.info('Getting specific task', { taskId });
      
      const params = {
        TableName: process.env.TABLE_NAME,
        Key: {
          id: taskId
        }
      };
      
      const result = await dynamodb.send(new GetCommand(params));
      
      // タスクが存在し、かつ現在のユーザーのものであることを確認
      if (!result.Item || result.Item.userId !== userId) {
        logger.error('Task not found or not authorized', { taskId });
        return createErrorResponse(404, 'Task not found');
      }
      
      logger.info('Task found', { taskId });
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(result.Item)
      };
    } 
    // ユーザーのすべてのタスクを取得
    else {
      logger.info('Getting all tasks for user');
      
      const params = {
        TableName: process.env.TABLE_NAME,
        IndexName: 'UserIdIndex',
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: {
          ':userId': userId
        }
      };
      
      const result = await dynamodb.send(new QueryCommand(params));
      logger.info('Tasks retrieved', { count: result.Items ? result.Items.length : 0 });
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(result.Items || [])
      };
    }
  } catch (error) {
    logger.error('Error in handleGet', error);
    return createErrorResponse(500, 'Error retrieving tasks', error);
  }
}

// POSTリクエストの処理
async function handlePost(event, userId) {
  try {
    logger.info('POST request received', { path: event.path, method: event.httpMethod });
    
    // リクエストボディのチェック
    if (!event.body) {
      logger.error('Request body is missing');
      return createErrorResponse(400, 'Request body is missing');
    }
    
    // Base64エンコードされたボディを処理
    let bodyStr = event.body;
    if (event.isBase64Encoded) {
      bodyStr = Buffer.from(event.body, 'base64').toString('utf-8');
      logger.info('Decoded base64 body length:', { length: bodyStr.length });
    }
    
    // JSONパース
    let body;
    try {
      body = JSON.parse(bodyStr);
      // センシティブでない情報のみログ出力
      logger.info('Request body parsed', { 
        hasTitle: !!body.title,
        hasDescription: !!body.description,
        status: body.status
      });
    } catch (e) {
      logger.error('JSON parse error', e, { bodyPreview: bodyStr.substring(0, 50) });
      return createErrorResponse(400, 'Invalid JSON in request body', e);
    }
    
    // 入力検証の強化
    // タイトルの検証 - 長さ制限と特殊文字のエスケープ
    if (!body.title || typeof body.title !== 'string') {
      logger.error('Title validation failed', { titleType: typeof body.title });
      return createErrorResponse(400, 'Title is required and must be a string');
    }
    
    // タイトルの長さ制限
    if (body.title.trim().length === 0 || body.title.length > 100) {
      logger.error('Title length validation failed', { titleLength: body.title.length });
      return createErrorResponse(400, 'Title must be between 1 and 100 characters');
    }
    
    // 説明の検証
    if (body.description !== undefined && (typeof body.description !== 'string' || body.description.length > 1000)) {
      logger.error('Description validation failed', { 
        descriptionType: typeof body.description,
        descriptionLength: body.description ? body.description.length : 0
      });
      return createErrorResponse(400, 'Description must be a string with maximum 1000 characters');
    }
    
    // ステータスの検証
    const validStatuses = ['pending', 'in-progress', 'completed'];
    if (body.status !== undefined && !validStatuses.includes(body.status)) {
      logger.error('Status validation failed', { providedStatus: body.status });
      return createErrorResponse(400, 'Invalid status value');
    }
    
    const taskId = generateUUID();
    logger.info('Generated task ID', { taskId });
    
    // 入力値のサニタイズ
    const sanitizedTitle = sanitizeHtml(body.title.trim());
    const sanitizedDescription = body.description ? sanitizeHtml(body.description) : '';
    
    // タスクオブジェクトの作成
    const task = {
      id: taskId,
      userId: userId,
      title: sanitizedTitle,
      description: sanitizedDescription,
      status: body.status || 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    logger.info('Creating task', { taskId, status: task.status });
    
    const params = {
      TableName: process.env.TABLE_NAME,
      Item: task
    };
    
    await dynamodb.send(new PutCommand(params));
    logger.info('Task created successfully', { taskId });
    
    return {
      statusCode: 201,
      headers: corsHeaders,
      body: JSON.stringify(task)
    };
  } catch (error) {
    logger.error('Error in handlePost', error);
    return createErrorResponse(500, 'Error creating task', error);
  }
}

// PUTリクエストの処理
async function handlePut(event, userId) {
  try {
    logger.info('PUT request received', { path: event.path, method: event.httpMethod });
    
    if (!event.pathParameters || !event.pathParameters.taskId) {
      logger.error('Task ID is missing in path parameters');
      return createErrorResponse(400, 'Task ID is required');
    }
    
    const taskId = event.pathParameters.taskId;
    logger.info('Updating task', { taskId });
    
    if (!event.body) {
      logger.error('Request body is missing');
      return createErrorResponse(400, 'Request body is missing');
    }
    
    // Base64エンコードされたボディを処理
    let bodyStr = event.body;
    if (event.isBase64Encoded) {
      bodyStr = Buffer.from(event.body, 'base64').toString('utf-8');
      logger.info('Decoded base64 body length:', { length: bodyStr.length });
    }
    
    // JSONパース
    let body;
    try {
      body = JSON.parse(bodyStr);
      // センシティブでない情報のみログ出力
      logger.info('Request body parsed', { 
        hasTitle: !!body.title,
        hasDescription: !!body.description,
        status: body.status
      });
    } catch (e) {
      logger.error('JSON parse error', e, { bodyPreview: bodyStr.substring(0, 50) });
      return createErrorResponse(400, 'Invalid JSON in request body', e);
    }
    
    // まず、タスクが存在し、現在のユーザーのものであることを確認
    const getParams = {
      TableName: process.env.TABLE_NAME,
      Key: {
        id: taskId
      }
    };
    
    try {
      logger.info('Checking if task exists', { taskId });
      const existingTask = await dynamodb.send(new GetCommand(getParams));
      
      if (!existingTask.Item) {
        logger.error('Task not found', { taskId });
        return createErrorResponse(404, 'Task not found');
      }
      
      if (existingTask.Item.userId !== userId) {
        logger.error('User not authorized to update this task', { 
          taskId,
          taskOwner: existingTask.Item.userId.substring(0, 5) + '...' // ユーザーIDの一部のみログ出力
        });
        return createErrorResponse(403, 'Not authorized to update this task');
      }
      
      logger.info('Task found and authorized', { taskId });
      
      // 入力検証の強化
      let updatedTitle = existingTask.Item.title;
      let updatedDescription = existingTask.Item.description;
      let updatedStatus = existingTask.Item.status;
      
      // タイトルの検証
      if (body.title !== undefined) {
        if (typeof body.title !== 'string') {
          logger.error('Title validation failed', { titleType: typeof body.title });
          return createErrorResponse(400, 'Title must be a string');
        }
        
        if (body.title.trim().length === 0 || body.title.length > 100) {
          logger.error('Title length validation failed', { titleLength: body.title.length });
          return createErrorResponse(400, 'Title must be between 1 and 100 characters');
        }
        
        updatedTitle = sanitizeHtml(body.title.trim());
      }
      
      // 説明の検証
      if (body.description !== undefined) {
        if (typeof body.description !== 'string' || body.description.length > 1000) {
          logger.error('Description validation failed', { 
            descriptionType: typeof body.description,
            descriptionLength: body.description ? body.description.length : 0
          });
          return createErrorResponse(400, 'Description must be a string with maximum 1000 characters');
        }
        
        updatedDescription = sanitizeHtml(body.description);
      }
      
      // ステータスの検証
      const validStatuses = ['pending', 'in-progress', 'completed'];
      if (body.status !== undefined) {
        if (!validStatuses.includes(body.status)) {
          logger.error('Status validation failed', { providedStatus: body.status });
          return createErrorResponse(400, 'Invalid status value');
        }
        
        updatedStatus = body.status;
      }
      
      // タスクを更新
      const updateParams = {
        TableName: process.env.TABLE_NAME,
        Key: {
          id: taskId
        },
        UpdateExpression: 'set title = :title, description = :description, #status_attr = :status, updatedAt = :updatedAt',
        ExpressionAttributeNames: {
          '#status_attr': 'status'  // 予約語をエスケープ
        },
        ExpressionAttributeValues: {
          ':title': updatedTitle,
          ':description': updatedDescription,
          ':status': updatedStatus,
          ':updatedAt': new Date().toISOString()
        },
        ReturnValues: 'ALL_NEW'
      };
      
      logger.info('Updating task with params', { 
        taskId,
        status: updatedStatus,
        updatedAt: updateParams.ExpressionAttributeValues[':updatedAt']
      });
      
      const result = await dynamodb.send(new UpdateCommand(updateParams));
      logger.info('Task updated successfully', { taskId });
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(result.Attributes)
      };
    } catch (dbError) {
      logger.error('DynamoDB error in handlePut', dbError);
      return createErrorResponse(500, 'Error updating task', dbError);
    }
  } catch (error) {
    logger.error('Error in handlePut', error);
    return createErrorResponse(500, 'Error updating task', error);
  }
}

// DELETEリクエストの処理
async function handleDelete(event, userId) {
  try {
    logger.info('DELETE request received', { path: event.path, method: event.httpMethod });
    
    if (!event.pathParameters || !event.pathParameters.taskId) {
      logger.error('Task ID is missing in path parameters');
      return createErrorResponse(400, 'Task ID is required');
    }
    
    const taskId = event.pathParameters.taskId;
    logger.info('Deleting task', { taskId });
    
    // まず、タスクが存在し、現在のユーザーのものであることを確認
    const getParams = {
      TableName: process.env.TABLE_NAME,
      Key: {
        id: taskId
      }
    };
    
    try {
      const existingTask = await dynamodb.send(new GetCommand(getParams));
      
      if (!existingTask.Item) {
        logger.error('Task not found', { taskId });
        return createErrorResponse(404, 'Task not found');
      }
      
      if (existingTask.Item.userId !== userId) {
        logger.error('User not authorized to delete this task', { 
          taskId,
          taskOwner: existingTask.Item.userId.substring(0, 5) + '...' // ユーザーIDの一部のみログ出力
        });
        return createErrorResponse(403, 'Not authorized to delete this task');
      }
      
      // タスクを削除
      const deleteParams = {
        TableName: process.env.TABLE_NAME,
        Key: {
          id: taskId
        }
      };
      
      await dynamodb.send(new DeleteCommand(deleteParams));
      logger.info('Task deleted successfully', { taskId });
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Task deleted successfully' })
      };
    } catch (dbError) {
      logger.error('DynamoDB error in handleDelete', dbError);
      return createErrorResponse(500, 'Error deleting task', dbError);
    }
  } catch (error) {
    logger.error('Error in handleDelete', error);
    return createErrorResponse(500, 'Error deleting task', error);
  }
}

// OPTIONSリクエストの処理（CORS対応）
function handleOptions() {
  logger.info('OPTIONS request received');
  return {
    statusCode: 200,
    headers: corsHeaders,
    body: JSON.stringify({})
  };
}

// Lambda関数のハンドラー
exports.handler = async (event) => {
  logger.info('Event received:', event);
  
  try {
    // OPTIONSリクエストの場合は即座にCORSヘッダーを返す
    if (event.httpMethod === 'OPTIONS') {
      return handleOptions();
    }
    
    // 認証チェックの強化
    if (!event.requestContext || !event.requestContext.authorizer || !event.requestContext.authorizer.claims) {
      logger.error('認証情報が不足しています');
      return createErrorResponse(401, 'Unauthorized - Missing authentication information');
    }
    
    // ユーザーIDを認証情報から取得
    const userId = event.requestContext.authorizer.claims.sub;
    if (!userId) {
      logger.error('ユーザーIDが見つかりません');
      return createErrorResponse(401, 'Unauthorized - User ID not found');
    }
    
    // トークンの有効期限をチェック
    const tokenExp = event.requestContext.authorizer.claims.exp;
    if (tokenExp) {
      const currentTime = Math.floor(Date.now() / 1000);
      if (currentTime > parseInt(tokenExp)) {
        logger.error('トークンの有効期限が切れています');
        return createErrorResponse(401, 'Unauthorized - Token expired');
      }
    }
    
    // トークンの発行者をチェック
    const tokenIssuer = event.requestContext.authorizer.claims.iss;
    if (tokenIssuer && !tokenIssuer.includes('cognito-idp')) {
      logger.error('不正な発行者からのトークンです:', { issuer: tokenIssuer });
      return createErrorResponse(401, 'Unauthorized - Invalid token issuer');
    }
    
    logger.info('User authenticated:', { userId });
    
    // HTTPメソッドに応じた処理
    switch(event.httpMethod) {
      case 'GET':
        return await handleGet(event, userId);
      case 'POST':
        return await handlePost(event, userId);
      case 'PUT':
        return await handlePut(event, userId);
      case 'DELETE':
        return await handleDelete(event, userId);
      default:
        return createErrorResponse(405, 'Method not allowed');
    }
  } catch (error) {
    logger.error('Error in handler:', error);
    return createErrorResponse(500, 'Internal server error', error);
  }
};
